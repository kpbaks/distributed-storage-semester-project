#!/bin/bash

bash <(curl -L zellij.dev/launch) -l deployment-pane-layout.zellij.kdl
