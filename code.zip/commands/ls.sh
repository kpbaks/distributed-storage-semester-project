#!/bin/bash

ls ../storage-node{0..3}
